//
//  DataBaseTest-BridgingHeader.h
//  DataBaseTest
//
//  Created by KairaNewMac on 08/08/17.
//  Copyright © 2017 Kaira Software. All rights reserved.
//

#ifndef DataBaseTest_BridgingHeader_h
#define DataBaseTest_BridgingHeader_h

#import <sqlite3.h>

#endif /* DataBaseTest_BridgingHeader_h */
